from Classes.pet import Pet
from Classes.dog import Dog
from Classes.cat import Cat
    





my_dog = Dog("Scout", 3, "German Shepherd")
print("My dogs name is: " + my_dog.name)
my_dog.clean()
print("My dogs breed is a " + my_dog.breed)

my_cat = Cat("Fluffy", 3)
print("My dogs name is: " + my_cat.name)