def getWorkplace():
    song = input("Please enter a current or former workplace or q to quit: ")
    return song
    