from Classes.Shirt import Shirt
my_shirt = Shirt("Medium", "Blue")
print("The attributes of myshirt are:")
print(my_shirt.size)
print(my_shirt.color)
my_shirt.printSizeandColor()

your_shirt = Shirt("Large", "Green")
print("The attributes of yourshirt are:")
print(your_shirt.size)
print(your_shirt.color)
your_shirt.printSizeandColor()