from Functions.function_library import *

user_first_name = getFirstName()

print("Welcome, " + user_first_name)